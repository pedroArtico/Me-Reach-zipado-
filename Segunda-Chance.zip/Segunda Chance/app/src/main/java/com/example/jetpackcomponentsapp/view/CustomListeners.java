package com.example.jetpackcomponentsapp.view;

import com.example.jetpackcomponentsapp.model.CustomModel;

public interface CustomListeners {


    void onDelete(CustomModel item, int position);
}
